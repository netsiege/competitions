# Proxmox API credentials
token_secret = "24f63a42-3da2-4a32-8c67-60c6ee664382"
token_id = "netsiege-admin@pve!netsiege-terraform"

# Infrastructure settings
proxmox_host        = "cuci-pve-02"
kali_template_name  = "kali-netsiege-b"
api_url             = "https://pve1.cyberuci.com/api2/json"
nic_name            = "vmbr3"
